import { NextResponse, type NextRequest } from 'next/server';
import { withAuth, jsonError } from '@/lib/api/auth';
import { rateLimit } from '@/lib/api/rateLimit';

export const runtime = 'nodejs';

/** GET /api/applications/received  → candidature per le opportunità create dall’utente corrente */
export const GET = withAuth(async (req: NextRequest, { supabase, user }) => {
  try { await rateLimit(req, { key: 'applications:RECEIVED', limit: 120, window: '1m' } as any); }
  catch { return jsonError('Too Many Requests', 429); }

  // 1) Opportunità dell’owner
  const { data: oppsOwner, error: eOwner } = await supabase
    .from('opportunities')
    .select('id, title, city, province, region, country, owner_id')
    .eq('owner_id', user.id);
  if (eOwner) return jsonError(eOwner.message, 400);

  let opps = oppsOwner ?? [];

  // Fallback per dati legacy con colonna created_by popolata
  if (!opps.length) {
    const { data: legacyOpps, error: legacyErr } = await supabase
      .from('opportunities')
      .select('id, title, city, province, region, country, created_by')
      .eq('created_by', user.id);
    if (legacyErr) return jsonError(legacyErr.message, 400);
    opps = (legacyOpps ?? []).map((row: any) => ({ ...row, owner_id: row.created_by }));
  }

  if (!opps.length) return NextResponse.json({ data: [] });

  const oppIds = opps.map(o => o.id);
  const oppMap = new Map(
    opps.map((o: any) => {
      const ownerId = o.owner_id ?? o.created_by ?? null;
      return [o.id, { ...o, owner_id: ownerId, created_by: ownerId }];
    })
  );

  // 2) Candidature su quelle opportunità
  const { data: rows, error: e2 } = await supabase
    .from('applications')
    .select('id, opportunity_id, athlete_id, note, status, created_at, updated_at')
    .in('opportunity_id', oppIds)
    .order('created_at', { ascending: false });
  if (e2) return jsonError(e2.message, 400);

  const apps = rows ?? [];
  if (!apps.length) return NextResponse.json({ data: [] });

  // 3) Profili atleti
  const athleteIds = Array.from(new Set(apps.map(a => a.athlete_id)));
  const { data: profs } = await supabase
    .from('profiles')
    .select('id, display_name, account_type, profile_type, type')
    .in('id', athleteIds);

  const profMap = new Map(
    (profs ?? []).map((p) => [
      p.id,
      {
        ...p,
        account_type: (p.account_type ?? p.profile_type ?? p.type ?? null) as string | null,
      },
    ])
  );

  // 4) Arricchisci
  const enhanced = apps.map(a => ({
    ...a,
    opportunity: oppMap.get(a.opportunity_id) ?? null,
    athlete: profMap.get(a.athlete_id) ?? null,
  }));

  return NextResponse.json({ data: enhanced });
});
