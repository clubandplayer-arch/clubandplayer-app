// app/applications/received/page.tsx
import { redirect } from 'next/navigation';

export default function Page() {
  redirect('/applications');
}
