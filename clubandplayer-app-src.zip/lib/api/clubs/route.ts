// Legacy placeholder: gli handler reali sono in app/api/*
// Questo modulo è intenzionalmente vuoto per evitare errori di build.
export {};
