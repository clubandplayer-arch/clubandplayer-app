export const regions = [
  'Abruzzo','Basilicata','Calabria','Campania','Emilia-Romagna','Friuli-Venezia Giulia',
  'Lazio','Liguria','Lombardia','Marche','Molise','Piemonte','Puglia','Sardegna',
  'Sicilia','Toscana','Trentino-Alto Adige','Umbria','Valle d\'Aosta','Veneto'
] as const

export type Region = typeof regions[number]

export const provincesByRegion: Record<Region, string[]> = {
  'Abruzzo': ['L\'Aquila','Teramo','Pescara','Chieti'],
  'Basilicata': ['Potenza','Matera'],
  'Calabria': ['Catanzaro','Cosenza','Crotone','Reggio Calabria','Vibo Valentia'],
  'Campania': ['Napoli','Salerno','Caserta','Avellino','Benevento'],
  'Emilia-Romagna': ['Bologna','Modena','Reggio Emilia','Parma','Piacenza','Ferrara','Ravenna','Forlì-Cesena','Rimini'],
  'Friuli-Venezia Giulia': ['Trieste','Gorizia','Pordenone','Udine'],
  'Lazio': ['Roma','Frosinone','Latina','Rieti','Viterbo'],
  'Liguria': ['Genova','Imperia','La Spezia','Savona'],
  'Lombardia': ['Milano','Bergamo','Brescia','Como','Cremona','Lecco','Lodi','Mantova','Monza e Brianza','Pavia','Sondrio','Varese'],
  'Marche': ['Ancona','Ascoli Piceno','Fermo','Macerata','Pesaro e Urbino'],
  'Molise': ['Campobasso','Isernia'],
  'Piemonte': ['Torino','Alessandria','Asti','Biella','Cuneo','Novara','Verbano-Cusio-Ossola','Vercelli'],
  'Puglia': ['Bari','Barletta-Andria-Trani','Brindisi','Foggia','Lecce','Taranto'],
  'Sardegna': ['Cagliari','Nuoro','Oristano','Sassari','Sud Sardegna'],
  'Sicilia': ['Agrigento','Caltanissetta','Catania','Enna','Messina','Palermo','Ragusa','Siracusa','Trapani'],
  'Toscana': ['Firenze','Arezzo','Grosseto','Livorno','Lucca','Massa-Carrara','Pisa','Pistoia','Prato','Siena'],
  'Trentino-Alto Adige': ['Bolzano','Trento'],
  'Umbria': ['Perugia','Terni'],
  'Valle d\'Aosta': ['Aosta'],
  'Veneto': ['Venezia','Belluno','Padova','Rovigo','Treviso','Verona','Vicenza']
}
